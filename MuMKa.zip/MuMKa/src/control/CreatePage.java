/***********************************************************************
 * Module:  CreatePage.java
 * Author:  Petar
 * Purpose: Defines the Class CreatePage
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;
import model.Collection;
import model.Document;
import model.Page;
import model.Workspace;
import view.ShowDocument;

/** @pdOid 01384cd1-cfb9-4fbf-b162-9055cec98fde */
@SuppressWarnings("serial")
public class CreatePage extends AbstractAction {
   /** @param e
    * @pdOid 79ab55be-06f0-48cf-91c3-3c0853d0422f */
   public void actionPerformed(ActionEvent e) {
	   Document c=null;
	   Page col = new Page();
	   col.getPanel().add(new JButton("Novo Dugme"));
	   if(e.getSource() instanceof JMenuItem) {
	   DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
	   if(childNodeView.getUserObject() instanceof Workspace || childNodeView.getUserObject() instanceof Collection) {
		   return;
	   }
	   
	   
	  /* col.addObserver(Singleton.getInstance().mainFrame.getTreeHandler());
	   col.notifyObserver(EventType.ADDED);*/
	   c =(Document)childNodeView.getUserObject();
	   
      // TODO: implement
	   }else if(e.getSource() instanceof JButton) {
		   c=((ShowDocument)((JButton)e.getSource()).getParent()).getDoc();
	   }
	   c.addPage(col);
   }

}