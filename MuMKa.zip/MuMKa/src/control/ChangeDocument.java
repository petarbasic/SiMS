/***********************************************************************
 * Module:  ChangeDocument.java
 * Author:  Petar
 * Purpose: Defines the Class ChangeDocument
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;
import model.Document;
import observer.EventType;
import view.AddDocument;

/** @pdOid 6ef30858-1c3e-4034-8a9d-c788d5133785 */
public class ChangeDocument extends AbstractAction {
   /** @param e
    * @pdOid 853563f5-10b3-4edd-a307-293eb4b66c72 */
   public void actionPerformed(ActionEvent e) {
	   DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
	   
	   AddDocument dialog = new AddDocument(Singleton.getInstance().mainFrame, "Izmena dokumenta","Naziv Dokumenta");
	   String rez=dialog.showDialog();
	   
	   if (rez.equals("")) {
		   return;
	   }
	   Document col = (Document)childNodeView.getUserObject();
	   col.setName(rez);
	   col.notifyObserver(EventType.CHANGED);
      // TODO: implement
   }

}