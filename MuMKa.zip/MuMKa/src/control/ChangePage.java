/***********************************************************************
 * Module:  ChangePage.java
 * Author:  Petar
 * Purpose: Defines the Class ChangePage
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

/** @pdOid f24b441a-1459-4b67-ba9d-112273fa7417 */
public class ChangePage extends AbstractAction {
   /** @param e
    * @pdOid 9cc1615f-9031-4c30-b25d-7dc664e2ecd6 */
   public void actionPerformed(ActionEvent e) {
      // TODO: implement
   }

}