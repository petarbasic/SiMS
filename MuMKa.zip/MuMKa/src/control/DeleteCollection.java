/***********************************************************************
 * Module:  DeleteCollection.java
 * Author:  Petar
 * Purpose: Defines the Class DeleteCollection
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;
import model.Collection;
import model.Workspace;
import observer.EventType;

/** @pdOid 0b43eae7-4b98-49a9-95d0-a3249902a824 */
public class DeleteCollection extends AbstractAction {
   /** @param e
    * @pdOid d9a06d3e-7c06-43c8-b94f-4784a75650b1 */
   public void actionPerformed(ActionEvent e) {
	   DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
	   
	   DefaultMutableTreeNode parent =(DefaultMutableTreeNode)childNodeView.getParent();
	   if(parent.getUserObject() instanceof Workspace) {
		   Workspace w =(Workspace)parent.getUserObject();
		   w.getPackages().remove(childNodeView.getUserObject());
	   }else {
		   Collection w=(Collection)parent.getUserObject();
		   w.getComponents().remove(childNodeView.getUserObject());
	   }
	   
	   Collection col = (Collection)childNodeView.getUserObject();
	   col.notifyObserver(EventType.REMOVED);
      // TODO: implement
   }

}