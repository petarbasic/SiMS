/***********************************************************************
 * Module:  ChangeCollection.java
 * Author:  Petar
 * Purpose: Defines the Class ChangeCollection
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;
import model.Collection;
import observer.EventType;
import view.AddCollection;

/** @pdOid 777195ea-24cb-4bbd-8cd6-0778944dafb1 */
public class ChangeCollection extends AbstractAction {
   /** @param e
    * @pdOid 3d4549e3-e1c5-48d2-bf74-a2586dd1d5ff */
   public void actionPerformed(ActionEvent e) {
		DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
	   
	   AddCollection dialog = new AddCollection(Singleton.getInstance().mainFrame, "Izmena kolekcije");
	   String rez=dialog.showDialog();
	   
	   if (rez.equals("")) {
		   return;
	   }
	   Collection col = (Collection)childNodeView.getUserObject();
	   col.setName(rez);
	   col.notifyObserver(EventType.CHANGED);
	   
      // TODO: implement
   }

}