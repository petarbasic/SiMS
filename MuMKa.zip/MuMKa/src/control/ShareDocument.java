
/***********************************************************************
* Module:  ShareDocument.java
* Author:  Petar
* Purpose: Defines the Class ShareDocument
***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import app.Singleton;
import model.Collection;
import model.Document;
import observer.EventType;

/** @pdOid 75259256-0093-4c4d-b47b-35c5e7984664 */
public class ShareDocument extends AbstractAction {
  /** @param e
   * @pdOid 254923da-b0fa-4769-a9ee-00515dd0cf27 */
@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	
	 DefaultListModel<DefaultMutableTreeNode> l1 = new DefaultListModel<DefaultMutableTreeNode>();  
	 DefaultMutableTreeNode tn = ((DefaultMutableTreeNode)Singleton.getInstance().mainFrame.getTreeHandler().getTreeModel().getRoot());
	
	 for (int i=0; i<tn.getChildCount();i++ ) {
		
		l1.addElement((DefaultMutableTreeNode) tn.getChildAt(i));
		addElements(l1,(DefaultMutableTreeNode) tn.getChildAt(i));
	}
     JList<DefaultMutableTreeNode> list = new JList<>(l1);  
     //list.setBounds(100,100, 75,75);  
	
	int result = JOptionPane.showConfirmDialog(null, list, "Izbor odredisne kolekcije", JOptionPane.YES_NO_OPTION);
	if (result == JOptionPane.YES_OPTION) {
	  DefaultMutableTreeNode sel=list.getSelectedValue();
	  DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
	  //System.out.println(sel.getName());
	  Document d = ((Document)childNodeView.getUserObject()).clone();
	  JTree tree= Singleton.getInstance().mainFrame.getTreeHandler().getTree();
	  TreePath tp =new TreePath(sel.getPath());
	  tree.setSelectionPath(tp);
	  ((Collection)sel.getUserObject()).getComponents().add(d);

	  d.notifyObserver(EventType.ADDED);
	} else {
	    System.out.println("User canceled / closed the dialog, result = " + result);
	}
}
private void addElements(DefaultListModel<DefaultMutableTreeNode> l1, DefaultMutableTreeNode c) {
	for (int i=0; i<c.getChildCount();i++ ) {
		if(((DefaultMutableTreeNode) c.getChildAt(i)).getUserObject() instanceof Collection)
		l1.addElement((DefaultMutableTreeNode) c.getChildAt(i));
		addElements(l1,(DefaultMutableTreeNode) c.getChildAt(i));
	}
	
}

}