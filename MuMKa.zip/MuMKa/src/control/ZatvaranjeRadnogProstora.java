/***********************************************************************
 * Module:  ZatvaranjeRadnogProstora.java
 * Author:  Petar
 * Purpose: Defines the Class ZatvaranjeRadnogProstora
 ***********************************************************************/

package control;


import java.awt.event.ActionEvent;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;
import model.Collection;
import model.Component;
import model.Document;
import model.Workspace;
import view.MenuBar;

/** @pdOid 141b3d33-2d99-4344-b4cc-826c1889d03d */
public class ZatvaranjeRadnogProstora extends AbstractAction {
   /** @param e
    * @pdOid 73a80646-1832-4205-b3ba-1dac7de2f33b */
   public void actionPerformed(ActionEvent e) {
	   DefaultMutableTreeNode root = (DefaultMutableTreeNode)Singleton.getInstance().mainFrame.getTreeHandler().getTree().getModel().getRoot();
		if (root == null ) {
			return;
		}
		Workspace koren=(Workspace)root.getUserObject();
		 int dialogButton = JOptionPane.YES_NO_OPTION;
			int dialogResult = JOptionPane.showConfirmDialog (null, "Da li zelite da sacuvate radni prostor?","Cuvanje radnog prostora",dialogButton);
		if(dialogResult==JOptionPane.YES_OPTION) {
				JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
				jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int returnValue = jfc.showSaveDialog(null);
				// int returnValue = jfc.showSaveDialog(null);

			if (returnValue == JFileChooser.APPROVE_OPTION) {
				String directoryName=jfc.getSelectedFile().getPath()+"/"+koren.getName();
				File directory = new File(directoryName);
			    if (! directory.exists()){
			        directory.mkdir();
			    }
			    for (Collection c : koren.getPackages()) {
			    	File col = new File(directoryName+"/"+c.getName());
			    	if (! col.exists()){
			    		col.mkdir();
				    }
			    	save(c,directoryName+"/"+c.getName());
				}
			}
		else {}
		}else {
	}
}
      // TODO: implement
   
public void save(Collection c,String directory) {
			for (Component com : c.getComponents()) {
				if(com instanceof Collection) {
					File col = new File(directory+"/"+((Collection)com).getName());
					if (! col.exists()){
			    		col.mkdir();
				    }
					save((Collection)com,directory+"/"+((Collection)com).getName());
				}else {
					File f = new File(directory+"/"+((Document)com).getName());
					if(f.exists()) {
						f.delete();
					}
					ObjectOutputStream oos=null;
					try {
						
						oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
						oos.writeObject((Document)com);
						oos.flush();
						oos.close();
						
					} catch ( IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
}
}