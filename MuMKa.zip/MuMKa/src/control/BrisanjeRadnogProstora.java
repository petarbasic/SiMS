/***********************************************************************
 * Module:  BrisanjeRadnogProstora.java
 * Author:  Petar
 * Purpose: Defines the Class BrisanjeRadnogProstora
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

/** @pdOid 0ccac3d2-c423-41a3-af64-abb49732fe8b */
public class BrisanjeRadnogProstora extends AbstractAction {
   /** @param e
    * @pdOid 44cd1565-8e69-47b5-a91b-4362dec05207 */
   public void actionPerformed(ActionEvent e) {
      // TODO: implement
   }

}