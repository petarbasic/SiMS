/***********************************************************************
 * Module:  IzmenaRadnogProstora.java
 * Author:  Petar
 * Purpose: Defines the Class IzmenaRadnogProstora
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileSystemView;

import app.Singleton;
import model.Workspace;
import view.MenuBar;

/** @pdOid 24c40692-38fc-4bd1-b2f2-0f804c502286 */
public class IzmenaRadnogProstora extends AbstractAction {
   /** @param e
    * @pdOid ad41f047-574e-4834-90d3-1802e25b7171 */
   public void actionPerformed(ActionEvent e) {
	  
		
			JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
			j.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			int rValue = j.showOpenDialog(null);
			// int returnValue = jfc.showSaveDialog(null);
			
			if (rValue == JFileChooser.APPROVE_OPTION) {
				Singleton.getInstance().mainFrame.getTreeHandler().getTree().setModel(null);;
				Singleton.getInstance().mainFrame.getTreeHandler().setWorkspace(null);
				((MenuBar)Singleton.getInstance().mainFrame.getJMenuBar()).deactivateAll(false);
				System.out.println("Ovde");
				File selectedFile= j.getSelectedFile();
				Singleton.getInstance().mainFrame.setWorkspace(new Workspace(selectedFile.getName(),selectedFile));
				Singleton.getInstance().mainFrame.getTreeHandler().setWorkspace(Singleton.getInstance().mainFrame.getWorkspace());
				Singleton.getInstance().mainFrame.getTreeHandler().initTree();
				Singleton.getInstance().mainFrame.getSplitPane().setLeftComponent(Singleton.getInstance().mainFrame.getTreeHandler().getTree());
				((MenuBar)Singleton.getInstance().mainFrame.getJMenuBar()).deactivateAll(true);
			}else {
				
			}
			
		
      // TODO: implement
   }

}