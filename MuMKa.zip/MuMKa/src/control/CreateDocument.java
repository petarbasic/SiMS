/***********************************************************************
 * Module:  CreateDocument.java
 * Author:  Petar
 * Purpose: Defines the Class CreateDocument
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;
import model.Collection;
import model.Document;
import model.Workspace;
import observer.EventType;
import view.AddDocument;

/** @pdOid afd641b9-1194-4537-8bc7-1a8759981b55 */
public class CreateDocument extends AbstractAction {
   /** @param e
    * @pdOid 014a3ec2-fa5f-432c-9f5c-74161823b562 */
   public void actionPerformed(ActionEvent e) {
      // TODO: implement
	   DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
	   if(childNodeView.getUserObject() instanceof Workspace || childNodeView.getUserObject() instanceof Document) {
		   return;
	   }
	   AddDocument dialog = new AddDocument(Singleton.getInstance().mainFrame, "Dodavanje dokumenta","Naziv dokumenta:");
	   String rez=dialog.showDialog();
	   
	   if (rez.equals("")) {
		   return;
	   }
	   Document col = new Document(rez);
	   col.addObserver(Singleton.getInstance().mainFrame.getTreeHandler());
	   col.notifyObserver(EventType.ADDED);
	   Collection c =(Collection)childNodeView.getUserObject();
	   c.getComponents().add(col);
   }

}