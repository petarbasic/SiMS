/***********************************************************************
 * Module:  DeleteDocument.java
 * Author:  Petar
 * Purpose: Defines the Class DeleteDocument
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;
import model.Collection;
import model.Document;
import observer.EventType;

/** @pdOid ccc6c8e1-2b68-495b-9463-6bd8d82b2088 */
public class DeleteDocument extends AbstractAction {
   /** @param e
    * @pdOid ef74cad2-e7d1-4148-b16b-00ca8d1f963c */
   public void actionPerformed(ActionEvent e) {
	   DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
	   
	   DefaultMutableTreeNode parent =(DefaultMutableTreeNode)childNodeView.getParent();
	   if(parent.getUserObject() instanceof Collection) {
		   Collection w=(Collection)parent.getUserObject();
		   w.getComponents().remove(childNodeView.getUserObject());
	   }
	   
	   Document col = (Document)childNodeView.getUserObject();
	   col.notifyObserver(EventType.REMOVED);
      // TODO: implement
   }

}