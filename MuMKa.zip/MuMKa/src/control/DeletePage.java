/***********************************************************************
 * Module:  DeletePage.java
 * Author:  Petar
 * Purpose: Defines the Class DeletePage
 ***********************************************************************/

package control;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Box;
import javax.swing.JButton;

import model.Document;
import model.Page;
import view.ShowDocument;

/** @pdOid 562d1b96-776e-46f4-bc11-88da9a5b4649 */
@SuppressWarnings("serial")
public class DeletePage extends AbstractAction {
   /** @param e
    * @pdOid f1b9e339-da39-41bc-9f8a-521ceb2f6d8a */
   public void actionPerformed(ActionEvent e) {
	   Document c=null;
	   Page col = null;
	   
	   if(e.getSource() instanceof JButton) {
		   c=((ShowDocument)((JButton)e.getSource()).getParent()).getDoc();
		   col=((ShowDocument)((JButton)e.getSource()).getParent()).getCurrPage();
		   if(c.getPage().size()>1) {
			   
			   Integer a=c.getPage().indexOf(col);
			   c.removePage(col);
				if(a.intValue()==(c.getPage().size()) ) {
					a=a-1;
				}else{
				}
				((ShowDocument)((JButton)e.getSource()).getParent()).setCurrPage(c.getPage().get(a.intValue()));
				a=a+1;
				((ShowDocument)((JButton)e.getSource()).getParent()).setPageNo(a.toString());
				((ShowDocument)((JButton)e.getSource()).getParent()).removeStranica(col.getPanel());
				((ShowDocument)((JButton)e.getSource()).getParent()).setStranica(((ShowDocument)((JButton)e.getSource()).getParent()).getCurrPage().getPanel());
				GridBagConstraints cs = new GridBagConstraints();
		    	cs.gridx=0;
		    	cs.gridy=1;
		    	cs.gridwidth=3;
		    	cs.gridheight=2;cs.insets=new Insets(12,12,12,12);cs.fill = GridBagConstraints.NONE;
		    	((ShowDocument)((JButton)e.getSource()).getParent()).add(((ShowDocument)((JButton)e.getSource()).getParent()).getCurrPage().getPanel(),cs);
				
				((ShowDocument)((JButton)e.getSource()).getParent()).revalidate();
				((ShowDocument)((JButton)e.getSource()).getParent()).repaint();
			}else {
				
			}
	   }
   }
	   
      // TODO: implement
}

