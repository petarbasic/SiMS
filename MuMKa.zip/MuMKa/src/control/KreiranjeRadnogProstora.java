/***********************************************************************
 * Module:  KreiranjeRadnogProstora.java
 * Author:  Petar
 * Purpose: Defines the Class KreiranjeRadnogProstora
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

/** @pdOid bf17274c-0dbf-4566-89c3-e099f8e2f885 */
public class KreiranjeRadnogProstora extends AbstractAction {
   /** @param e
    * @pdOid 21bfd45e-9e05-4ecd-9275-3ece99f32bb9 */
   public void actionPerformed(ActionEvent e) {
      // TODO: implement
   }

}