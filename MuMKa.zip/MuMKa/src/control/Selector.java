/***********************************************************************
 * Module:  Selector.java
 * Author:  Petar
 * Purpose: Defines the Class Selector
 ***********************************************************************/

package control;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;
import model.Collection;
import model.Workspace;
import view.MenuBar;

/** @pdOid e606eb85-de0b-43d1-9b01-242200e46350 */
public class Selector implements TreeSelectionListener {
   /** @param event
    * @pdOid 931c9139-5655-4703-b6d6-de490a311345 */
   public void valueChanged(TreeSelectionEvent event) {
	    DefaultMutableTreeNode obj = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
	   if(obj==null) {
	    	return;
	   }
	   MenuBar m=((MenuBar)Singleton.getInstance().mainFrame.getJMenuBar());
	   if(obj.getUserObject() instanceof Workspace) {
		   
		   m.getChangeCollection().setEnabled(false);
		   m.getChangeDocument().setEnabled(false);
		   m.getChangeWorkspace().setEnabled(true);
		   m.getAddCollection().setEnabled(true);
		   m.getAddDocument().setEnabled(false);
		   
	   }else if(obj.getUserObject() instanceof Collection) {
		   m.getChangeCollection().setEnabled(true);
		   m.getChangeDocument().setEnabled(false);
		   m.getChangeWorkspace().setEnabled(false);
		   m.getAddCollection().setEnabled(true);
		   m.getAddDocument().setEnabled(true);
	   }else {
		   m.getChangeCollection().setEnabled(false);
		   m.getChangeDocument().setEnabled(true);
		   m.getChangeWorkspace().setEnabled(false);
		   m.getAddCollection().setEnabled(false);
		   m.getAddDocument().setEnabled(false);
	   }
      // TODO: implement
   }

}