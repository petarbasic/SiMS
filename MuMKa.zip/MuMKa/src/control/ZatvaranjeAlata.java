/***********************************************************************
 * Module:  ZatvaranjeAlata.java
 * Author:  Petar
 * Purpose: Defines the Class ZatvaranjeAlata
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import app.Parameters;
import app.Singleton;

/** @pdOid ef5ffd6e-1679-4b6e-a77b-13b39064a6d7 */
public class ZatvaranjeAlata implements WindowListener {
   
  
   /** @param e
    * @pdOid ddecfa38-0c04-406e-9973-8f2b6763ed5e */
   public void actionPerformed(ActionEvent e) {
      // TODO: implement
   }

@Override
public void windowOpened(WindowEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public void windowClosing(WindowEvent e) {
	// TODO Auto-generated method stub
	ZatvaranjeRadnogProstora z = new ZatvaranjeRadnogProstora();
	z.actionPerformed(new ActionEvent(e.getSource(),0,null));
	
	File f = new File("parameters.p");
	ObjectOutputStream oos=null;
	Parameters p=Singleton.getInstance().mainFrame.getParam();
		if(f.exists()) {
			f.delete();
		}
		try {
			oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
			oos.writeObject(p);
			oos.close();
			
		} catch ( IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Singleton.getInstance().mainFrame.dispose();
		System.exit(1);
}

@Override
public void windowClosed(WindowEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public void windowIconified(WindowEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public void windowDeiconified(WindowEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public void windowActivated(WindowEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public void windowDeactivated(WindowEvent e) {
	// TODO Auto-generated method stub
	
}

}