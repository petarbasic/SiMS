/***********************************************************************
 * Module:  CreateCollection.java
 * Author:  Petar
 * Purpose: Defines the Class CreateCollection
 ***********************************************************************/

package control;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;
import model.Collection;
import model.Workspace;
import observer.EventType;
import view.AddCollection;

/** @pdOid 9e1449c6-ca29-4fd5-82f3-3f613f1faf71 */
public class CreateCollection extends AbstractAction {
	public CreateCollection() {// TODO Auto-generated constructor stub
		}
   public CreateCollection(String string) {
	   super(string);
		// TODO Auto-generated constructor stub
	}

/** @param e
    * @pdOid 15b15040-94c5-4325-bd27-4b0dc8a946bf */
   public void actionPerformed(ActionEvent e) {

		DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
		
		
		
		
		
	   AddCollection dialog = new AddCollection(Singleton.getInstance().mainFrame, "Dodavanje kolekcije");
	   String rez=dialog.showDialog();
	   
	   if (rez.equals("")) {
		   return;
	   }
	   Collection col = new Collection(rez);
	   col.addObserver(Singleton.getInstance().mainFrame.getTreeHandler());
	   col.notifyObserver(EventType.ADDED);
	   if(childNodeView.getUserObject() instanceof Workspace) {
			Workspace c = (Workspace)childNodeView.getUserObject();
			c.getPackages().add(col);
	   }else if(childNodeView.getUserObject() instanceof Collection) {
		   Collection c = (Collection)childNodeView.getUserObject();
			c.getComponents().add(col);
	   }
	   
      // TODO: implement
   }

}