/***********************************************************************
 * Module:  Slot.java
 * Author:  Petar
 * Purpose: Defines the Class Slot
 ***********************************************************************/

package model;

import java.io.Serializable;

/** @pdOid 936117fd-2aaa-4d98-89f9-c16009f3febe */
public class Slot implements Serializable {
}