/***********************************************************************
 * Module:  Component.java
 * Author:  Petar
 * Purpose: Defines the Interface Component
 ***********************************************************************/

package model;

import javax.swing.tree.DefaultMutableTreeNode;

/** @pdOid f73355fa-359c-4e46-a35a-4eb13f4ec0a8 */
public interface Component {
   /** @param root
    * @pdOid 9b3478d6-d4d7-4e99-a9e4-53ddce4c1ab0 */
   void addChilds(DefaultMutableTreeNode root);

}