/***********************************************************************
 * Module:  Collection.java
 * Author:  Petar
 * Purpose: Defines the Class Collection
 ***********************************************************************/

package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;

import observer.Observer;

/** @pdOid 3c5dbfca-82cb-4923-a2ab-ea5fcd5d8e0f */
public class Collection implements Component, Serializable, observer.Observable {
   /** @pdOid 87180f92-25f6-44a1-a4e5-d6bf26a1af52 */
   private String name;
   /** @pdOid 8f4d7557-dd43-4ec9-bc45-b12f1f05def0 */
   private ArrayList<Component> components;
   
   List<Observer> observers = new ArrayList<Observer>();
   /** @pdRoleInfo migr=no name=Document assc=association2 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Composition */
   public java.util.Collection<Document> document;
   
   /** @param root
    * @pdOid 655efeac-3cd1-474b-a0fb-7b7dda39c557 */
   public void addChilds(DefaultMutableTreeNode root) {
      // TODO: implement
	   for (Component c : this.components) {
			DefaultMutableTreeNode node = new DefaultMutableTreeNode(c);
			if(c instanceof Collection) {
				c.addChilds(node);
			}
			root.add(node);
		}
   }
   
   /** @pdOid 3b69c0e0-ab0e-4fca-b0db-9f32e023661b */
   public String getName() {
      return name;
   }
   
   /** @param newName
    * @pdOid 0115601e-fc2b-4edf-8e7e-5b5bec38a8b5 */
   public void setName(String newName) {
      name = newName;
   }
   
   /** @pdOid 1bfcdcc5-6707-40b0-bdf3-b1a4a67cd766 */
   public ArrayList<Component> getComponents() {
      return components;
   }
   
   /** @param newComponents
    * @pdOid 8daf9e0a-2dcf-4c55-8671-f2f1210b1bfc */
   public void setComponents(ArrayList<Component> newComponents) {
      components = newComponents;
   }
   
   /** @param name 
    * @param components
    * @pdOid 3d8754dd-1334-4ec7-94a1-40ff68464af0 */
   public Collection(String name, ArrayList<Component> components) {
      // TODO: implement
   }
   
   /** @pdOid 787811ba-d684-4ea5-b795-3080de629aba */
   public Collection() {
      // TODO: implement
   }
   public Collection(String name) {
	   this.name=name;
	   components=new ArrayList<Component>();
	   observers=new ArrayList<Observer>();
	      // TODO: implement
	   }
   
   
   /** @pdGenerated default getter */
   public java.util.Collection<Document> getDocument() {
      if (document == null)
         document = new java.util.HashSet<Document>();
      return document;
   }
   
   /** @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorDocument() {
      if (document == null)
         document = new java.util.HashSet<Document>();
      return document.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newDocument */
   public void setDocument(java.util.Collection<Document> newDocument) {
      removeAllDocument();
      for (java.util.Iterator iter = newDocument.iterator(); iter.hasNext();)
         addDocument((Document)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newDocument */
   public void addDocument(Document newDocument) {
      if (newDocument == null)
         return;
      if (this.document == null)
         this.document = new java.util.HashSet<Document>();
      if (!this.document.contains(newDocument))
         this.document.add(newDocument);
   }
   
   /** @pdGenerated default remove
     * @param oldDocument */
   public void removeDocument(Document oldDocument) {
      if (oldDocument == null)
         return;
      if (this.document != null)
         if (this.document.contains(oldDocument))
            this.document.remove(oldDocument);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllDocument() {
      if (document != null)
         document.clear();
   }

	@Override
	public void notifyObserver(Object arg) {
		for (Observer o : observers) {
			o.update(this, arg);
		}
	}

	@Override
	public void addObserver(Observer observer) {
		this.observers.add(observer);
	}

	@Override
	public void removeObserver(Observer observer) {
		this.observers.remove(observer);
	}

	@Override
	public String toString() {
		return  name ;
	}
	
}

