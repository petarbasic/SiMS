/***********************************************************************
 * Module:  Document.java
 * Author:  Petar
 * Purpose: Defines the Class Document
 ***********************************************************************/

package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;

import observer.Observer;

/** @pdOid 6982ffca-ccee-4380-802e-f9b552c01a10 */
public class Document implements Component, Serializable, observer.Observable {
   /** @pdOid 62fe7de8-ae75-47b3-b9e2-19674e0076af */
   private String name;
   /** @pdOid 3a260998-d09e-448a-8ca7-04854bc0856d */
  private ArrayList<Page> pages;
  transient  List<Observer> observers = new ArrayList<Observer>();
   

   /** @pdOid a0c7612f-6858-4a8a-a347-9a90c6c33084 */
   public Document() {
      // TODO: implement
   }
   public Document(String name) {
	      // TODO: implement
	   	this.name=name;
	   	pages=new ArrayList<Page>();
	   	pages.add(new Page());
   }
   public String getName() {
		return name;
	   }
	public void setName(String name) {
		this.name = name;
	}
   /** @pdGenerated default getter */
   public ArrayList<Page> getPage() {
      
      return pages;
   }

   public void addPage(Page newPage) {
      if (newPage == null)
         return;
      if (this.pages == null)
         this.pages = new ArrayList<Page>();
      if (!this.pages.contains(newPage))
         this.pages.add(newPage);
   }
   
   /** @pdGenerated default remove
     * @param oldPage */
   public void removePage(Page oldPage) {
      if (oldPage == null)
         return;
      if (this.pages != null)
         if (this.pages.contains(oldPage))
            this.pages.remove(oldPage);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllPage() {
      if (pages != null)
         pages.clear();
   }


	@Override
	public void notifyObserver(Object arg) {
		for (Observer o : observers) {
			o.update(this, arg);
		}
	}

	@Override
	public void addObserver(Observer observer) {
		if(this.observers==null) {
			this.observers=new ArrayList<Observer>();
		}
		this.observers.add(observer);
	}

	@Override
	public void removeObserver(Observer observer) {
		this.observers.remove(observer);
	}
@Override
public void addChilds(DefaultMutableTreeNode root) {
	// TODO Auto-generated method stub
	
}
public Document clone() {
	Document document = new Document(this.name);
	document.getPage().clear();
	for (Page p : this.pages) {
		document.getPage().add(p);
		
	}
	for (Observer observer : this.observers) {
		document.observers.add(observer);
	}
	return document;
}

}