/***********************************************************************
 * Module:  Page.java
 * Author:  Petar
 * Purpose: Defines the Class Page
 ***********************************************************************/

package model;

import java.awt.Color;
import java.awt.Dimension;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

import observer.Observer;

/** @pdOid 20d71fd1-fd6b-4890-bce8-dfc583fefc45 */
public class Page implements Serializable, observer.Observable {
   /** @pdOid f4cf8d9b-b803-4793-adb7-ae5fdab62aae */
   private ArrayList<Slot> slots;
   JPanel panel;
   /** @pdRoleInfo migr=no name=Slot assc=association4 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Composition */
  
   
   /** @pdOid 5f8406c4-2d7a-4c42-9b9b-0805eecd322a */
   public Page() {
      // TODO: implement
	   slots=new ArrayList<Slot>();
	   panel=new JPanel();
	   panel.setPreferredSize(new Dimension(350,550));
	   panel.setMinimumSize(new Dimension(300,500));
	   panel.setBackground(new Color(255,255,255));
	   panel.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.black, Color.black));
   }
  
   
   
   /** @pdGenerated default getter */
   public ArrayList<Slot> getSlots() {
      if (slots == null)
         slots = new ArrayList<Slot>();
      return slots;
   }
  
   /** @pdGenerated default add
     * @param newSlot */
   public void addSlot(Slot newSlot) {
      if (newSlot == null)
         return;
      if (this.slots == null)
         this.slots = new ArrayList<Slot>();
      if (!this.slots.contains(newSlot))
         this.slots.add(newSlot);
   }
   
   /** @pdGenerated default remove
     * @param oldSlot */
   public void removeSlot(Slot oldSlot) {
      if (oldSlot == null)
         return;
      if (this.slots != null)
         if (this.slots.contains(oldSlot))
            this.slots.remove(oldSlot);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllSlot() {
      if (slots != null)
         slots.clear();
   }


public JPanel getPanel() {
	return panel;
}


public void setPanel(JPanel panel) {
	this.panel = panel;
}


@Override
public void notifyObserver(Object arg0) {
	// TODO Auto-generated method stub
	
}


@Override
public void addObserver(Observer arg0) {
	// TODO Auto-generated method stub
	
}


@Override
public void removeObserver(Observer arg0) {
	// TODO Auto-generated method stub
	
}

}