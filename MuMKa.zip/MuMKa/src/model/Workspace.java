/***********************************************************************
 * Module:  Workspace.java
 * Author:  Petar
 * Purpose: Defines the Class Workspace
 ***********************************************************************/

package model;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;

import app.Singleton;

/** @pdOid 2cc40f24-a776-4ce2-85fa-1840f56e08b2 */
@SuppressWarnings("serial")
public class Workspace implements Serializable {
   /** @pdOid 3f53d09f-fc34-42cb-b964-ba6cb3a467cf */
   private String name;
   /** @pdOid 2e309d3e-b42c-402f-b6d4-73237381c5fa */
   private ArrayList<Collection> packages;
   
   /** @pdRoleInfo migr=no name=Collection assc=association1 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Composition */
   
   
   /** @param name 
    * @param packages
    * @pdOid 75a8c269-5955-439f-a9eb-b0c8162afcff */
   public Workspace(String name, File fileRoot) {
      // TODO: implement
	   this.name=name;
	   packages=new ArrayList<Collection>();
	   File[] files = fileRoot.listFiles();
	   if(files!=null) {
		   for (File file : files) {
			   if (!file.isDirectory()) {
				   continue;
			   }
			   Collection childNode = 
	                   new Collection(file.getName());
			   childNode.addObserver(Singleton.getInstance().mainFrame.getTreeHandler());
			   packages.add(childNode);
	               createChildren(file, childNode);
	           
		   }
	   }
	  
	   
   }
   private void createChildren(File fileRoot, 
           Collection node) {
       File[] files = fileRoot.listFiles();
       if (files == null) return;

       for (File file : files) {
           Component childNode=null; 
           if (file.isDirectory()) {
        	   childNode=new Collection(file.getName());
        	   ((Collection)childNode).addObserver(Singleton.getInstance().mainFrame.getTreeHandler());
        	   //packages.add((Collection)childNode);
               createChildren(file, (Collection)childNode);
               
           }else {
        	   ObjectInputStream oos=null;
				try {
					
					oos = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
					childNode=(Document)oos.readObject();
					
					oos.close();
					
				} catch ( IOException | ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					return; 
					
				}
        	   
        	   ((Document)childNode).addObserver(Singleton.getInstance().mainFrame.getTreeHandler());
           }
           
           node.getComponents().add(childNode);
       }
   }
   /** @pdOid a24f1c8b-5629-4170-831b-ceff69f0d425 */
   public void workspace() {
      // TODO: implement
   }
   
   /** @pdOid 0536ef02-4a23-400e-8ff7-0bd59f05dca8 */
   public String getName() {
      return name;
   }
   
   /** @param newName
    * @pdOid a36e8161-fec5-4576-8714-87d2590267b7 */
   public void setName(String newName) {
      name = newName;
   }
   
   /** @pdOid b688575a-3ae9-47af-b170-03a14e22ec6c */
   public List<Collection> getPackages() {
      return packages;
   }
   
   /** @param newPackages
    * @pdOid 0170b5e0-3e52-4743-bc81-a4cf9a5577a4 */
   public void setPackages(ArrayList<Collection> newPackages) {
      packages = newPackages;
   }
  
   public void addChilds(DefaultMutableTreeNode root) {
		
		for (Collection p : this.packages) {
			DefaultMutableTreeNode node = new DefaultMutableTreeNode(p);
			p.addChilds(node);
			root.add(node);
		}
	}
   /** @pdGenerated default removeAll */
  
}