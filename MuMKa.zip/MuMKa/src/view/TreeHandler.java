/***********************************************************************
 * Module:  TreeHandler.java
 * Author:  Petar
 * Purpose: Defines the Class TreeHandler
 ***********************************************************************/

package view;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;

import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import app.Singleton;
import control.Selector;
import model.Collection;
import model.Document;
import model.Workspace;
import observer.EventType;
import observer.Observable;

/** @pdOid b9f573fa-d9da-490f-a9ae-859ef610ed83 */
public class TreeHandler implements observer.Observer {
   /** @pdOid a5bd8c57-6306-431f-b52d-6b5a3ea22945 */
   private JTree tree;
   /** @pdOid 1cff8b75-f4b3-48aa-ba13-69e1436c7f23 */
   private DefaultTreeModel treeModel;
   /** @pdOid 0bc38dc5-3e66-4fcf-a0da-76c398986d3e */
   private DefaultMutableTreeNode root;
   /** @pdOid 25ba140c-0013-4de7-96f1-4f9a49ecc326 */
   private Workspace workspace;
   
   
/** @param workspace
    * @pdOid 3c1bceae-0dcd-4fe5-b924-05e0c5309a21 */
   public TreeHandler(Workspace workspace) {
      // TODO: implement
	   this.workspace=workspace;
   }
   public TreeHandler() {
	      // TODO: implement
		  
	   }
   
/** @param tree 
    * @param model 
    * @param root
    * @pdOid ed932bbf-3513-4437-98f6-556cc49d7b3b */
   public TreeHandler(JTree tree, DefaultTreeModel model, DefaultMutableTreeNode root) {
	   this.tree = tree;
		this.treeModel = model;
		this.root = root;
      // TODO: implement
   }
   
   /** @pdOid 69ca0cdb-5d44-4e84-8988-d55e83aab26e */
   public void initTree() {
	   
	   initData();
		
		this.treeModel = new DefaultTreeModel(this.root);
		this.treeModel.setAsksAllowsChildren(true);
		this.tree = new JTree(treeModel) {

			private static final long serialVersionUID = 2789999619139248302L;

			@Override
			public boolean isPathEditable(TreePath path) {
				return false;
			}
		};
		this.tree.setEditable(true);
		this.tree.setCellRenderer(new NodeTreeCellRenderer());
		expandAllNodes(this.tree, 0, tree.getRowCount());
		this.tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);	
		tree.getSelectionModel().addTreeSelectionListener(new Selector());
		this.tree.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {

			    if (SwingUtilities.isRightMouseButton(e)) {

			        int row = tree.getClosestRowForLocation(e.getX(), e.getY());
			        tree.setSelectionRow(row);
			        Object node = ((DefaultMutableTreeNode)tree.getLastSelectedPathComponent()).getUserObject();
			        new TreeContextMenu(tree, node).show(e.getComponent(), e.getX(), e.getY());
			    }
			    
	            int selRow = tree.getRowForLocation(e.getX(), e.getY());
	            TreePath selPath = tree.getPathForLocation(e.getX(), e.getY());
	            if(selRow != -1) {
	              if(e.getClickCount() == 2) {
	            	  Object node = ((DefaultMutableTreeNode)tree.getLastSelectedPathComponent()).getUserObject();
	            	  if (node instanceof Document) {
	            		  Singleton.getInstance().mainFrame.getSplitPane().remove( Singleton.getInstance().mainFrame.getScrollPaneView());
	            		  Singleton.getInstance().mainFrame.getSplitPane().setRightComponent(new JScrollPane(new ShowDocument((Document)node)));
	            	  }
	                }
	            }
			        
			  
			  
			}
		});
      // TODO: implement
		System.out.println("DRVO");
   }
   private void expandAllNodes(JTree tree, int startingIndex, int rowCount){
	    for(int i=startingIndex;i<rowCount;++i){
	        tree.expandRow(i);
	    }

	    if(tree.getRowCount()!=rowCount){
	        expandAllNodes(tree, rowCount, tree.getRowCount());
	    }
	}
   
   /** @pdOid 011e7d3f-f664-45d3-9714-97c0c2bf25ac */
   public void initData() {
	   this.root = new DefaultMutableTreeNode(this.workspace);
		this.workspace.addChilds(root);
      // TODO: implement
   }
@Override
public void update(Observable arg0, Object arg1) {
	// TODO Auto-generated method stub
	@SuppressWarnings("unchecked")
	Enumeration<DefaultMutableTreeNode> en = ((DefaultMutableTreeNode) treeModel
			.getRoot()).breadthFirstEnumeration();
	
	if (arg1 == EventType.REMOVED) {
		if(arg0 instanceof Collection) {
			Collection col = (Collection)arg0;
			while (en.hasMoreElements()) {
				DefaultMutableTreeNode curr = en.nextElement();
				// voditi racuna oko id-a i jedinstvenosti
				// u realnom radu sa bazom, id bi svakako bio jedinstven
				if (curr.getUserObject() instanceof Collection && 
						((Collection)curr.getUserObject()).getName().equals(col.getName())) {
					this.treeModel.removeNodeFromParent(curr);
				}
			}
		}else if(arg0 instanceof Document) {
			Document col = (Document)arg0;
			while (en.hasMoreElements()) {
				DefaultMutableTreeNode curr = en.nextElement();
				// voditi racuna oko id-a i jedinstvenosti
				// u realnom radu sa bazom, id bi svakako bio jedinstven
				if (curr.getUserObject() instanceof Document && 
						((Document)curr.getUserObject()).equals(col)) {
					this.treeModel.removeNodeFromParent(curr);
				}
			}
		}
	
		
		
	} else if (arg1 == EventType.ADDED) {
		if(arg0 instanceof Collection) {
			Collection col = (Collection)arg0;
		
		
		DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
		
		this.treeModel.insertNodeInto(new DefaultMutableTreeNode(col), childNodeView, childNodeView.getChildCount());
		}else if(arg0 instanceof Document) {
			Document col = (Document)arg0;
		
		
		DefaultMutableTreeNode childNodeView = (DefaultMutableTreeNode) Singleton.getInstance().mainFrame
				.getTreeHandler().getTree().getLastSelectedPathComponent();
		
		this.treeModel.insertNodeInto(new DefaultMutableTreeNode(col), childNodeView, childNodeView.getChildCount());
		//this.treeModel.
		}
	}else if (arg1==EventType.CHANGED) {
		
	}
	
}
public JTree getTree() {
	return tree;
}
public void setTree(JTree tree) {
	this.tree = tree;
}
public DefaultTreeModel getTreeModel() {
	return treeModel;
}
public void setTreeModel(DefaultTreeModel treeModel) {
	this.treeModel = treeModel;
}
public DefaultMutableTreeNode getRoot() {
	return root;
}
public void setRoot(DefaultMutableTreeNode root) {
	this.root = root;
}
public Workspace getWorkspace() {
	return workspace;
}
public void setWorkspace(Workspace workspace) {
	this.workspace = workspace;
}

}