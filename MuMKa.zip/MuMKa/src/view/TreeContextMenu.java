/***********************************************************************
 * Module:  TreeContextMenu.java
 * Author:  Petar
 * Purpose: Defines the Class TreeContextMenu
 ***********************************************************************/

package view;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import javax.swing.JTree;

import control.ChangeCollection;
import control.ChangeDocument;
import control.CreateCollection;
import control.CreateDocument;
import control.CreatePage;
import control.DeleteCollection;
import control.DeleteDocument;
import control.ShareDocument;
import model.Collection;
import model.Document;
import model.Workspace;

/** @pdOid 8d270c06-3f0c-481b-8656-1ea0094f0b97 */
@SuppressWarnings("serial")
public class TreeContextMenu extends JPopupMenu {
   /** @pdOid 0e42efcc-0686-4f99-aa4a-207a0d919bb5 */
   private JMenuItem addCollection;
   private JMenuItem changeCollection;
   /** @pdOid 1448027a-4cad-4c34-851f-6988e235c665 */
   private JMenuItem removeCollection;
   /** @pdOid 3c06f3b8-51c3-454b-870d-5a64a5b551bb */
   private JMenuItem addDocument;
   /** @pdOid 8ccf8633-b556-4bee-9414-333bfcc63347 */
   private JMenuItem addPage;
   /** @pdOid 8ccf8633-b556-4bee-9414-333bfcc63347 */
   private JMenuItem changeDocument;
   /** @pdOid 4fca3b1b-32fb-47e3-96f1-2a1cd2bb6f71 */
   private JMenuItem removeDocument;
   /** @pdOid 8ccf8633-b556-4bee-9414-333bfcc63347 */
   private JMenuItem shareDocument;
   /** @pdOid 8ccf8633-b556-4bee-9414-333bfcc63347 */
   private JMenuItem show;
   
   /** @param tree 
    * @param item
    * @pdOid 2a82f050-1f7a-41e1-9f42-b3534c7c3416 */
   public TreeContextMenu(JTree tree, Object item) {
	    addCollection = new JMenuItem("Dodaj kolekciju");
		addCollection.addActionListener(new CreateCollection());
	   if (item instanceof Workspace) {
			add(addCollection);
		} else if (item instanceof Collection) {
			removeCollection = new JMenuItem("Ukloni kolekciju");
			addDocument = new JMenuItem("Dodaj dokument");
			changeCollection = new JMenuItem("Izmeni kolekciju");
			
			changeCollection.addActionListener(new ChangeCollection());
			removeCollection.addActionListener(new DeleteCollection());
			addDocument.addActionListener(new CreateDocument());
			
			add(addCollection);
			add(changeCollection);
			add(removeCollection);
			add(new JSeparator());
			add(addDocument);
		} else if (item instanceof Document) {
			//JMenuItem openData = new JMenuItem("Open");
			
			removeDocument = new JMenuItem("Ukloni dokument");
			changeDocument = new JMenuItem("Izmeni dokument");
			addPage=new JMenuItem("Dodaj stranicu");
			addPage.addActionListener(new CreatePage());
			changeDocument.addActionListener(new ChangeDocument());
			shareDocument = new JMenuItem("Podeli dokument");
			shareDocument.addActionListener(new ShareDocument() );
			removeDocument.addActionListener(new DeleteDocument());
			
			add(changeDocument);
			add(removeDocument);
			add(addPage);
			add(shareDocument);
		}
      // TODO: implement
   }

}