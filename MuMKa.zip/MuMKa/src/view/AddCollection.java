/***********************************************************************
 * Module:  AddCollection.java
 * Author:  Petar
 * Purpose: Defines the Class AddCollection
 ***********************************************************************/

package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import control.CreateCollection;
@SuppressWarnings("serial")
/** @pdOid e1aeac87-1d9b-4eb2-aed2-92b2e20aaaa6 */
public class AddCollection extends JDialog {
   /** @pdOid 69192365-216f-49b2-af03-4aa15d888928 */
   private JLabel name;
   /** @pdOid 3e186f05-f74b-429a-a381-235036a47a9e */
   private JButton addButton;
   /** @pdOid 403a4c65-5be5-4083-95f2-39e47ad76067 */
   private JTextField textFieldName;
   /** @pdOid 5e25666d-b2d6-4022-a37f-887e7bed2b18 */
   private JButton cancelButton;
   
   /** @pdOid 5414a02d-ac82-49bb-8c56-a56b6ed8a772 */
   public AddCollection(JFrame parent,String title) {
	   super(parent, title, true);
	   setLayout(new BorderLayout());

		Dimension lblDimension=new Dimension(150,20);
		
		Box boxCentar = new Box(BoxLayout.Y_AXIS);
		JPanel p=new JPanel();
		p.setLayout(new BorderLayout());
		JPanel pan = new JPanel(new FlowLayout(FlowLayout.LEFT));
		name = new JLabel("Naziv kolekcije:");
		name.setPreferredSize(lblDimension);
		textFieldName= new JTextField(20);
		textFieldName.setBackground(Color.white);
		pan.add(name);
		pan.add(textFieldName);
	
		boxCentar.add(pan);
		p.add(boxCentar,BorderLayout.CENTER);
		add(p, BorderLayout.CENTER);
		setResizable(false);
		JPanel buttonPanels = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		
		addButton = new JButton(title.equals("Izmena kolekcije")? "Izmeni":"Dodaj");
		cancelButton = new JButton("Otkazi");
		addButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				dispose();
				
			}
		});
		cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				textFieldName.setText("");
				setVisible(false);	
				dispose();
			}
		});
		buttonPanels.add(addButton);
		buttonPanels.add(cancelButton);
		add(buttonPanels, BorderLayout.SOUTH);
		
		pack();
		setLocationRelativeTo(null);
		this.getRootPane().setDefaultButton(addButton);
      // TODO: implement
   }
   
   /** @pdOid 696e6108-cf6c-4534-af27-26cafce71856 */
   public void initComponents() {
      // TODO: implement
   }
   public String showDialog() {
	    setVisible(true);
	    return textFieldName.getText();
	}
   /** @pdOid c1620519-4e83-436a-925c-2b946fd0b492 */
   public JTextField getTextFieldName() {
      return textFieldName;
   }
   
   /** @param newTextFieldName
    * @pdOid da25ea26-dee3-4575-833f-3c9603d31afc */
   public void setTextFieldName(JTextField newTextFieldName) {
      textFieldName = newTextFieldName;
   }

}