/***********************************************************************
 * Module:  ChangeDocument.java
 * Author:  Petar
 * Purpose: Defines the Class ChangeDocument
 ***********************************************************************/

package view;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/** @pdOid d23526b2-1890-49fd-92f0-48d643f11c75 */
public class ChangeDocument extends JDialog {
   /** @pdOid e6211ba9-42a7-4d6e-8418-c5b016103c83 */
   private JLabel name;
   /** @pdOid 3a7ed4a1-5620-4315-8f82-0714b7e89b24 */
   private JButton changeButton;
   /** @pdOid 5a014fe4-fb01-4a94-9fa5-aa459330c299 */
   private JButton cancelButton;
   /** @pdOid 7593a0e4-ca45-488c-a3ab-ed1e0680e25a */
   private JTextField textFieldName;
   
   /** @pdOid 2cff4f82-7b5f-47c8-85fc-d8f6260a8896 */
   public void changeDocument() {
      // TODO: implement
   }
   
   /** @pdOid d3d7ca33-b8f8-4da3-9200-358b4794d100 */
   public void initComponents() {
      // TODO: implement
   }
   
   /** @pdOid 6d1b9ce4-c9cf-4fdb-9492-53ee2f6657fe */
   public JTextField getTextFieldName() {
      return textFieldName;
   }
   
   /** @param newTextFieldName
    * @pdOid 39a111bf-9920-4756-86ec-4f7b1a1960f2 */
   public void setTextFieldName(JTextField newTextFieldName) {
      textFieldName = newTextFieldName;
   }

}