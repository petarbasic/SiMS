/***********************************************************************
 * Module:  LoadingDialog.java
 * Author:  Petar
 * Purpose: Defines the Class LoadingDialog
 ***********************************************************************/

package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

/** @pdOid fcc340b5-4fed-4440-bc78-c1592e3dafb6 */
public class LoadingDialog extends JDialog {
	public static final int OK=0;
	public static final int CANCEL=1;
	
	private LoadingPanel panel;
	
	private int closingMode = LoadingDialog.CANCEL;
   /** @pdOid 86aa0f6f-34d2-4e85-b011-a107c6817afc */
   public LoadingDialog(JFrame parent, String title) {
	   super(parent, title, true);
	   panel = new LoadingPanel();
	   setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		add(panel, BorderLayout.CENTER);
		setResizable(false);
		
		JPanel buttonPanels = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		
		JButton okButton = new JButton("Ok");
		okButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				closingMode = OK;
				LoadingPanel pan = (LoadingPanel)panel;
					boolean ok=true;
					if (pan.getPathTextField().getText().trim().equals("")){
						pan.getPathTextField().setBackground(Color.RED);
						ok=true;
					}
					if (ok){
						setVisible(false);	
					}
			}
		});
		
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				closingMode = CANCEL;
				setVisible(false);	
			}
		});
		buttonPanels.add(okButton);
		buttonPanels.add(cancelButton);
		add(buttonPanels, BorderLayout.SOUTH);
		
		pack();
		setLocationRelativeTo(null);
		this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                parent.dispose();
            }
       });
	   
   }
   public LoadingPanel getPanel() {
		return panel;
	}

	public void setPanel(LoadingPanel panel) {
		this.panel = panel;
	}

	public int getClosingMode() {
		return closingMode;
	}

	public void setClosingMode(int closingMode) {
		this.closingMode = closingMode;
	}

}