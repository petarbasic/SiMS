/***********************************************************************
 * Module:  AddDocument.java
 * Author:  Petar
 * Purpose: Defines the Class AddDocument
 ***********************************************************************/

package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/** @pdOid 68dd23cb-e8fe-4453-8675-e2619e7fdb8d */
public class AddDocument extends JDialog {
   /** @pdOid d3088976-e6c4-445b-b7d0-6f30d3cd78db */
   private JLabel name;
   /** @pdOid 1cbf42e1-7ff2-46db-a0c4-ae68fd3bba07 */
   private JButton addButton;
   /** @pdOid 2d261dfb-c92b-44c2-b483-3c827a91f86a */
   private JButton cancelButton;
   /** @pdOid bff54cb3-d734-4b63-aabd-d15d4a3a56b4 */
   private JTextField textFieldName;
   
   /** @pdOid a43407af-9ab5-4bb1-8975-0c8952a21ba0 */
   public JTextField getTextFieldName() {
      return textFieldName;
   }
   
   /** @param newTextFieldName
    * @pdOid 8cf6dfed-4d94-499e-96cd-4947602d8252 */
   public void setTextFieldName(JTextField newTextFieldName) {
      textFieldName = newTextFieldName;
   }
   
   /** @pdOid 24bc14d4-5052-4e94-939f-aa6ff9d29ab0 */
   public void initComponents() {
      // TODO: implement
   }
   
   /** @pdOid d8b25e93-e7b4-4d67-948e-891c342abfde */
   public AddDocument(JFrame parent,String title,String lbl) {
	   super(parent, title, true);
	   setLayout(new BorderLayout());

		Dimension lblDimension=new Dimension(150,20);
		
		Box boxCentar = new Box(BoxLayout.Y_AXIS);
		JPanel p=new JPanel();
		p.setLayout(new BorderLayout());
		JPanel pan = new JPanel(new FlowLayout(FlowLayout.LEFT));
		name = new JLabel(lbl);
		name.setPreferredSize(lblDimension);
		textFieldName= new JTextField(20);
		textFieldName.setBackground(Color.white);
		pan.add(name);
		pan.add(textFieldName);
	
		boxCentar.add(pan);
		p.add(boxCentar,BorderLayout.CENTER);
		add(p, BorderLayout.CENTER);
		setResizable(false);
		JPanel buttonPanels = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		
		addButton = new JButton(title.equals("Izmena dokumenta")? "Izmeni":"Dodaj");
		cancelButton = new JButton("Otkazi");
		addButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				setVisible(false);
				dispose();
				
			}
		});
		cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				textFieldName.setText("");
				setVisible(false);	
				dispose();
			}
		});
		buttonPanels.add(addButton);
		buttonPanels.add(cancelButton);
		add(buttonPanels, BorderLayout.SOUTH);
		
		pack();
		setLocationRelativeTo(null);
		this.getRootPane().setDefaultButton(addButton);
      // TODO: implement
   }
   public String showDialog() {
	    setVisible(true);
	    return textFieldName.getText();
	}

}