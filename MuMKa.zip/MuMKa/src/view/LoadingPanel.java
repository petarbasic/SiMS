/***********************************************************************
 * Module:  LoadingPanel.java
 * Author:  Petar
 * Purpose: Defines the Class LoadingPanel
 ***********************************************************************/

package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileSystemView;

/** @pdOid aa73d017-9e47-4d7e-ba3e-dd6cc54cb016 */
public class LoadingPanel extends JPanel {
   /** @pdOid f56ea6de-e538-41ff-bdb0-510a84bc3173 */
   private JLabel pathLabel;
   /** @pdOid c41c90a1-c4a9-442e-a972-b126537205e4 */
   private JTextField pathTextField;
   /** @pdOid fcab778b-6224-409b-8c6a-d14722b86600 */
   private JButton pathButton;
   
   /** @pdOid 687ff920-25d6-4e77-97f9-c73e8f04de1f */
   public LoadingPanel() {
	   super();
      // TODO: implement
	   setLayout(new BorderLayout());

		Dimension lblDimension=new Dimension(150,20);
		
		Box boxCentar = new Box(BoxLayout.Y_AXIS);
		
		JPanel pan = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pathLabel = new JLabel("Path to workspace: ");
		pathLabel.setPreferredSize(lblDimension);
		pathTextField= new JTextField(20);
		
		pathTextField.setBackground(Color.white);
		pathButton=new JButton("Pretrazi");
		
		pathButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
				jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int returnValue = jfc.showOpenDialog(null);
				// int returnValue = jfc.showSaveDialog(null);

				if (returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile= jfc.getSelectedFile();
					pathTextField.setText(selectedFile.getPath());
					
				}
				
			}
		});
		pan.add(pathLabel);
		pan.add(pathTextField);
		pan.add(pathButton);
		boxCentar.add(pan);
		add(boxCentar,BorderLayout.CENTER);
   }
   
   /** @pdOid 7d607233-abba-4dcb-9b95-ccc23ceea560 */
   public JLabel getPathLabel() {
      return pathLabel;
   }
   
   /** @param newPathLabel
    * @pdOid 820ed955-8fbf-457f-98f3-d21a6421d4c7 */
   public void setPathLabel(JLabel newPathLabel) {
      pathLabel = newPathLabel;
   }
   
   /** @pdOid 412cb5dd-5da9-4900-98bb-1c6f3b4a725a */
   public JTextField getPathTextField() {
      return pathTextField;
   }
   
   /** @param newPathTextField
    * @pdOid c94086f3-8902-46f6-bf18-438163cc8daf */
   public void setPathTextField(JTextField newPathTextField) {
      pathTextField = newPathTextField;
   }

}