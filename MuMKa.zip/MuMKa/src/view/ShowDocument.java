/***********************************************************************
 * Module:  ShowDocument.java
 * Author:  Petar
 * Purpose: Defines the Class ShowDocument
 ***********************************************************************/

package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.text.NumberFormatter;

import app.Singleton;
import control.CreatePage;
import control.DeletePage;
import model.Document;
import model.Page;

/** @pdOid c089b7ce-32e9-4859-843d-cb1baf196c36 */
@SuppressWarnings("serial")
public class ShowDocument extends JPanel {
   /** @pdOid 015cc81f-7676-4905-9479-3b6d66dfcb82 */
   private JPanel stranica;
   /** @pdOid 973244e4-4434-4865-bb05-de2cf756f611 */
   private JFormattedTextField pageNo;
   /** @pdOid 35b89fe1-eafe-45ee-a86d-05ec0aed49c4 */
   private JButton rightButton;
   /** @pdOid 8318e46e-41fe-4549-aece-7bf025579a0e */
   private JButton leftButton;
   private JButton removePageButton;
   private JButton addPageButton;
   private Document doc;
   private Page currPage;
   public ShowDocument(Document d) {
	   doc=d;
	   this.setLayout(new GridBagLayout());
	   setSize(new Dimension(580,515));
	   NumberFormat longFormat = NumberFormat.getIntegerInstance();
	   this.setBackground(new Color(200,200,200));
	   NumberFormatter numberFormatter = new NumberFormatter(longFormat);
	   numberFormatter.setValueClass(Long.class); //optional, ensures you will always get a long value
	  // numberFormatter.setAllowsInvalid(false); //this is the key!!
	   numberFormatter.setMinimum(0l); //Optional
	   currPage=doc.getPage().get(0);
	   stranica=(currPage.getPanel());
	   
	   
	   pageNo = new JFormattedTextField(numberFormatter);
	   pageNo.setText("1");
	   pageNo.setPreferredSize(new Dimension(50,35));
	   pageNo.setMaximumSize(new Dimension(70,30));
	   pageNo.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			int a = Integer.parseInt(pageNo.getText());
			if (a>0 && a<=doc.getPage().size()) {
				currPage=doc.getPage().get(a-1);
				((ShowDocument)((Box)((JFormattedTextField)e.getSource()).getParent()).getParent()).remove(stranica);
				stranica=currPage.getPanel();
				GridBagConstraints c = new GridBagConstraints();
		    	c.gridx=0;
		    	c.gridy=1;
		    	c.gridwidth=3;
		    	c.gridheight=2;c.insets=new Insets(12,12,12,12);c.fill = GridBagConstraints.NONE;
		    	((ShowDocument)((Box)((JFormattedTextField)e.getSource()).getParent()).getParent()).add(stranica,c);
			}else {
				Integer b=doc.getPage().indexOf(currPage);
				b=b+1;
				pageNo.setText(b.toString());
			}
			((ShowDocument)((Box)((JFormattedTextField)e.getSource()).getParent()).getParent()).revalidate();
			((ShowDocument)((Box)((JFormattedTextField)e.getSource()).getParent()).getParent()).repaint();
			// TODO Auto-generated method stub
			
		}
	});
	   leftButton=new JButton();
	   leftButton.setIcon(Singleton.ikona("images/leftArrow.png"));
	   leftButton.setMaximumSize(new Dimension(30,30));
	   leftButton.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			Integer a=doc.getPage().indexOf(currPage);
			if(a.intValue()<1) {
				
			}else{
				currPage=doc.getPage().get(a-1);
				
				pageNo.setText(a.toString());
				((ShowDocument)((Box)((JButton)e.getSource()).getParent()).getParent()).remove(stranica);
				stranica=currPage.getPanel();
				GridBagConstraints c = new GridBagConstraints();
		    	c.gridx=0;
		    	c.gridy=1;
		    	c.gridwidth=3;
		    	c.gridheight=2;c.insets=new Insets(12,12,12,12);c.fill = GridBagConstraints.NONE;
		    	((ShowDocument)((Box)((JButton)e.getSource()).getParent()).getParent()).add(stranica,c);
			}
			((ShowDocument)((Box)((JButton)e.getSource()).getParent()).getParent()).revalidate();
			((ShowDocument)((Box)((JButton)e.getSource()).getParent()).getParent()).repaint();
		}
	});
	   rightButton=new JButton();
	   rightButton.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			Integer a=doc.getPage().indexOf(currPage);
			if(a.intValue()==(doc.getPage().size()-1)) {
				
			}else{
				currPage=doc.getPage().get(a+1);
				a=a+2;
				pageNo.setText(a.toString());
				((ShowDocument)((Box)((JButton)e.getSource()).getParent()).getParent()).remove(stranica);
				stranica=currPage.getPanel();
				GridBagConstraints c = new GridBagConstraints();
		    	c.gridx=0;
		    	c.gridy=1;
		    	c.gridwidth=3;
		    	c.gridheight=2;c.insets=new Insets(12,12,12,12);c.fill = GridBagConstraints.NONE;
		    	((ShowDocument)((Box)((JButton)e.getSource()).getParent()).getParent()).add(stranica,c);
		    	
			}
			((ShowDocument)((Box)((JButton)e.getSource()).getParent()).getParent()).revalidate();
			((ShowDocument)((Box)((JButton)e.getSource()).getParent()).getParent()).repaint();
		}
	});
	   rightButton.setIcon(Singleton.ikona("images/rightArrow.png"));
	   rightButton.setMaximumSize(new Dimension(30,30));
	   stranica.setPreferredSize(new Dimension(350,550));
	   stranica.setMinimumSize(new Dimension(300,500));
	   stranica.setBackground(new Color(255,255,255));
	   stranica.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.black, Color.black));
	   
	   Box box3=Box.createHorizontalBox();
    	box3.add(leftButton);
    	box3.add(pageNo);
    	box3.add(rightButton);
    	GridBagConstraints c = new GridBagConstraints();
    	c.gridx=0;
    	c.gridy=1;
    	c.gridwidth=3;
    	c.gridheight=2;c.insets=new Insets(12,12,4,12);c.fill = GridBagConstraints.NONE;
    	//c.ipady=600;
    	//c.ipadx=600;
	   this.add(stranica,c);
	   c.gridx=2;
	   c.gridy=3;
	   c.gridwidth=1;
	   c.gridheight=1;
	   c.insets=new Insets(1,12,1,12);
	   c.fill = GridBagConstraints.VERTICAL;
	   c.anchor=GridBagConstraints.PAGE_END;
	   this.add(box3,c);
	   c.anchor=GridBagConstraints.LAST_LINE_START;
	   removePageButton = new JButton ("Izbrisi stranicu");
	   removePageButton.setPreferredSize(new Dimension(120,25));
	   removePageButton.addActionListener(new DeletePage());
	   c.gridx=2; c.gridy=4;
	   this.add(removePageButton, c);
	   c.fill = GridBagConstraints.VERTICAL;
	   c.anchor=GridBagConstraints.LAST_LINE_END;
	   addPageButton=new JButton("Dodaj stranicu");
	   addPageButton.setPreferredSize(new Dimension(120,25));
	   addPageButton.addActionListener(new CreatePage());
	   //c.gridx=4;c.gridy=3;
	   this.add(addPageButton, c);
	   
	   this.setVisible(true);
   }
public Document getDoc() {
	return doc;
}
public void setDoc(Document doc) {
	this.doc = doc;
}
public Page getCurrPage() {
	return currPage;
}
public void setCurrPage(Page currPage) {
	this.currPage = currPage;
}
public JFormattedTextField getPageNo() {
	return pageNo;
}
public void setPageNo(String pageNo) {
	this.pageNo.setText(pageNo);
}
public JPanel getStranica() {
	return stranica;
}
public void setStranica(JPanel stranica) {
	this.stranica = stranica;
}
public void removeStranica(JPanel s) {
	this.remove(s);
}

}