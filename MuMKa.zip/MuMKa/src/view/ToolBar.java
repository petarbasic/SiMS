/***********************************************************************
 * Module:  ToolBar.java
 * Author:  Petar
 * Purpose: Defines the Class ToolBar
 ***********************************************************************/

package view;

import javax.swing.JToolBar;

/** @pdOid 98f5e667-e10f-489a-9764-ce94082dc24f */
public class ToolBar extends JToolBar {
}