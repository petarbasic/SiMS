/***********************************************************************
 * Module:  NodeTreeCellRenderer.java
 * Author:  Petar
 * Purpose: Defines the Class NodeTreeCellRenderer
 ***********************************************************************/

package view;

import java.awt.Component;

import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

import model.Collection;
import model.Document;
import model.Workspace;

/** @pdOid 97184e9b-49b1-413d-8011-a096955cff29 */
public class NodeTreeCellRenderer extends DefaultTreeCellRenderer {
   /** @pdOid 36b9f36f-620e-44bb-b99b-f54af59b202a */
   public NodeTreeCellRenderer(){
      // TODO: implement
   }
   
   /** @param tree 
    * @param value 
    * @param sel 
    * @param expander 
    * @param leaf 
    * @param row 
    * @param hasFocus
    * @pdOid d5882039-2c56-4e53-84b3-7897e8f27e1c */
   public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expander, boolean leaf, int row, boolean hasFocus) {
      // TODO: implement
	   super.getTreeCellRendererComponent(tree, value, sel, expander, leaf, row, hasFocus);

		if (value instanceof DefaultMutableTreeNode) {

			Object node = ((DefaultMutableTreeNode)value).getUserObject();
			
			if (node == null) {
				return this;
			}
			
			String iconPath, text = "";
			
			if (node instanceof Workspace) {
				iconPath = "images/ws.png";
				text = ((Workspace)node).getName();
			} else if (node instanceof Collection) {
				iconPath = "images/col.png";
				text = ((Collection)node).getName();
			} else {
				iconPath = "images/doc.png";
				text = ((Document)node).getName();
			} 
			
			setIcon(new ImageIcon(iconPath));
			setText(text);
		}

		return this;
   }

}