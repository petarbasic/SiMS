/***********************************************************************
 * Module:  MenuBar.java
 * Author:  Petar
 * Purpose: Defines the Class MenuBar
 ***********************************************************************/

package view;

import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import app.Singleton;
import control.ChangeCollection;
import control.ChangeDocument;
import control.CreateCollection;
import control.CreateDocument;
import control.IzmenaRadnogProstora;
import control.KreiranjeRadnogProstora;
import control.ZatvaranjeRadnogProstora;

/** @pdOid 91850834-a500-47e7-adce-29894059416c */
@SuppressWarnings("serial")
public class MenuBar extends JMenuBar {
  

/** @pdOid 090ae464-a5f1-433f-a938-4793a4b8e1db */
   private JMenu add;
   private JMenu help;
   private JMenuItem addCollection;
	private JMenuItem addWorkspace;
	private JMenuItem addDocument;
	private JMenuItem iClose;
	private JMenuItem iHelp;
	private JMenuItem changeWorkspace;
	private JMenuItem changeCollection;
	private JMenuItem changeDocument;
	private JCheckBoxMenuItem text;
	private JCheckBoxMenuItem picture;
	private JCheckBoxMenuItem video;
	private JCheckBoxMenuItem audio;
   /** @pdOid 56576c61-da39-4116-a28a-8760dda6f1a3 */
   private JMenu change;
   /** @pdOid 9de903b3-5c59-4129-9708-9a15bfb46dc1 */
   private JMenu monotipes;
   public MenuBar(JFrame parent) {
	   
	   add=new JMenu("File");
		add.setMnemonic('F');
	Font font = new Font("Verdana",Font.PLAIN,16);
		add.setFont(font);
	//Sledece linije potrebno izmeniti/dopuniti
		addWorkspace = new JMenuItem();
		addWorkspace.setText("Novi radni prostor");
		addWorkspace.setCursor(new Cursor(Cursor.HAND_CURSOR));
		addWorkspace.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, ActionEvent.CTRL_MASK));
		addWorkspace.addActionListener(new KreiranjeRadnogProstora());
		//addWorkspace.setIcon(ikona("slike/plus.png"));
		addCollection = new JMenuItem("Dodaj kolekciju");
		addCollection.setCursor(new Cursor(Cursor.HAND_CURSOR));
		addCollection.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));

		addCollection.addActionListener(new CreateCollection());
		//addCollection.setIcon(ikona("slike/cancel.png"));
		
	addDocument =new JMenuItem("Dodaj dokument");
	addDocument.setCursor(new Cursor(Cursor.HAND_CURSOR));
	addDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.CTRL_MASK));
	addDocument.addActionListener(new CreateDocument());
	//addDocument.setIcon(ikona("slike/refresh.png"));
	/*iLoad = new JMenuItem(new Loading(Main_Frame.getInstance().getResourceBundle().getString("iLoad")));
		iLoad.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, ActionEvent.ALT_MASK));
	iSave =new JMenuItem(new Saving(Main_Frame.getInstance().getResourceBundle().getString("iSave"))	);
	
		iSave.setCursor(new Cursor(Cursor.HAND_CURSOR));
		iSave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.ALT_MASK));
	
	iSaveAs =new JMenuItem(Main_Frame.getInstance().getResourceBundle().getString("iSaveAs"));
		iSaveAs.setCursor(new Cursor(Cursor.HAND_CURSOR));
	*/
	iClose =new JMenuItem("Zatvori");
		iClose.setCursor(new Cursor(Cursor.HAND_CURSOR));
		iClose.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.ALT_MASK));
		iClose.addActionListener(new ZatvaranjeRadnogProstora());
		/*iClose.addActionListener(new ActionListener() {
@Overrided actionPerformed(ActionEvent actionEvent) {
	System
public voi.exit(0);
}
});*/
	
	add.setCursor(new Cursor(Cursor.HAND_CURSOR));
	add.add(addWorkspace);
	add.add(addCollection);
	add.add(addDocument);
	add.addSeparator();
	add.add(iClose);

	add(add);
	//Edit komponenta
	change=new JMenu("Izmeni");
	change.setMnemonic('I');
	change.setFont(font);
	change.setCursor(new Cursor(Cursor.HAND_CURSOR));
	changeWorkspace = new JMenuItem();
	changeWorkspace.setText("Izmeni radni prostor");
	changeWorkspace.setAccelerator(KeyStroke.getKeyStroke("control shift W"));

	changeWorkspace.setCursor(new Cursor(Cursor.HAND_CURSOR));
	changeWorkspace.addActionListener(new IzmenaRadnogProstora());
	changeCollection = new JMenuItem("Izmeni kolekciju");
	changeCollection.setCursor(new Cursor(Cursor.HAND_CURSOR));
	changeCollection.addActionListener(new ChangeCollection());
	changeCollection.setAccelerator(KeyStroke.getKeyStroke("control shift C"));
	changeDocument= new JMenuItem("izmeni dokument");
	changeDocument.setCursor(new Cursor(Cursor.HAND_CURSOR));
	changeDocument.addActionListener(new ChangeDocument());
	changeDocument.setAccelerator(KeyStroke.getKeyStroke("control shift D"));
	change.add(changeWorkspace);
	change.add(changeCollection);
	change.add(changeDocument);
	add(change);
	
	
	
	
	
	monotipes=new JMenu("Monotipovi");
	monotipes.setMnemonic('M');
	monotipes.setFont(font);

	text=new JCheckBoxMenuItem("Tekst");
	text.setSelected(Singleton.getInstance().mainFrame.getParam().isText());
	text.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Singleton.getInstance().mainFrame.getParam().setText(text.isSelected());
		}
	});
	monotipes.add(text);
	
	picture=new JCheckBoxMenuItem("Slika");
	picture.setSelected(Singleton.getInstance().mainFrame.getParam().isPicture());
	picture.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Singleton.getInstance().mainFrame.getParam().setPicture(picture.isSelected());
		}
	});
	monotipes.add(picture);
	video=new JCheckBoxMenuItem("Video");
	video.setSelected(Singleton.getInstance().mainFrame.getParam().isVideo());
	video.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Singleton.getInstance().mainFrame.getParam().setVideo(video.isSelected());
		}
	});
	monotipes.add(video);
	audio=new JCheckBoxMenuItem("Audio");
	audio.setSelected(Singleton.getInstance().mainFrame.getParam().isAudio());
	audio.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			Singleton.getInstance().mainFrame.getParam().setAudio(audio.isSelected());
		}
	});
	monotipes.add(audio);
	add(monotipes);
	help=new JMenu("Help");
	help.setMnemonic('H');
	help.setFont(font);
	iHelp = new JMenuItem("Help");
	iHelp.addActionListener(new AbstractAction(){
		private static final long serialVersionUID = 1L;

		public void actionPerformed(ActionEvent arg0) {
			
		}
	});
	
	help.add(iHelp);
	add(help);
}
private ImageIcon ikona(String loc) {
	ImageIcon ikonica3=new ImageIcon(loc);
	Image img = ikonica3.getImage();
	Image newimg = img.getScaledInstance(12, 12,  java.awt.Image.SCALE_SMOOTH);
	return new ImageIcon(newimg);
}

public void initComponents(){
	
}
public void deactivateAll(boolean b) {
	  getChangeCollection().setEnabled(false);
	   getChangeDocument().setEnabled(false);
	   getChangeWorkspace().setEnabled(false);
	   getAddCollection().setEnabled(false);
	   getAddDocument().setEnabled(false);
	   iClose.setEnabled(b);
}
public JMenuItem getAddCollection() {
	return addCollection;
}
public JMenuItem getAddWorkspace() {
	return addWorkspace;
}
public JMenuItem getAddDocument() {
	return addDocument;
}
public JMenuItem getiClose() {
	return iClose;
}
public JMenuItem getiHelp() {
	return iHelp;
}
public JMenuItem getChangeWorkspace() {
	return changeWorkspace;
}
public JMenuItem getChangeCollection() {
	return changeCollection;
}
public JMenuItem getChangeDocument() {
	return changeDocument;
}
public JCheckBoxMenuItem getText() {
	return text;
}
public JCheckBoxMenuItem getPicture() {
	return picture;
}
public JCheckBoxMenuItem getVideo() {
	return video;
}
public JCheckBoxMenuItem getAudio() {
	return audio;
}


}