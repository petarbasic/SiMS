/***********************************************************************
 * Module:  ChangeCollection.java
 * Author:  Petar
 * Purpose: Defines the Class ChangeCollection
 ***********************************************************************/

package view;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/** @pdOid f5b4f08b-f38e-4fb0-b825-90c46cf20fe2 */
public class ChangeCollection extends JDialog {
   /** @pdOid 12fe5912-da4e-4983-8a78-10cd235849c2 */
   private JLabel name;
   /** @pdOid 498e3981-72aa-4126-9f2e-176cf8c5c0a5 */
   private JButton changeButton;
   /** @pdOid e2ff87fe-fef8-4d85-8334-cd244cea7a9e */
   private JButton cancelButton;
   /** @pdOid 05f5b5cb-fd3c-404b-afab-8a8f5f71c0b0 */
   private JTextField textFieldName;

}