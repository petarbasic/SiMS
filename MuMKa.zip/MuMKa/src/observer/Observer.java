/***********************************************************************
 * Module:  Observer.java
 * Author:  Petar
 * Purpose: Defines the Interface Observer
 ***********************************************************************/

package observer;

/** @pdOid 5abf2e2b-2411-46a2-99fb-e1c9c1640c21 */
public interface Observer {
   /** @param arg0 
    * @param arg1
    * @pdOid 3f4faf74-8e78-4124-ab86-d3a0c505b61b */
   void update(Observable arg0, Object arg1);

}