/***********************************************************************
 * Module:  Observable.java
 * Author:  Petar
 * Purpose: Defines the Interface Observable
 ***********************************************************************/

package observer;

/** @pdOid 0ee8d2e6-ac6d-4fec-9d7a-25be5b5b3c51 */
public interface Observable {
   /** @param arg0
    * @pdOid bcfb3598-0fb2-4dc8-b04f-11fe062a71a0 */
   void notifyObserver(Object arg0);
   /** @param arg0
    * @pdOid 07d61ebb-bcbb-485d-ac9f-2b0158417f0b */
   void addObserver(Observer arg0);
   /** @param arg0
    * @pdOid c85ffe1a-22ff-4f18-9e70-561844fa9e98 */
   void removeObserver(Observer arg0);

}