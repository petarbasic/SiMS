package observer;

public enum EventType {
	ADDED, REMOVED,CHANGED
}
