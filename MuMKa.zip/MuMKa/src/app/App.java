/***********************************************************************
 * Module:  App.java
 * Author:  Petar
 * Purpose: Defines the Class App
 ***********************************************************************/

package app;

/** @pdOid 39acc15d-330a-4a12-94f9-e329c5941294 */
public class App {
   /** @param agrs
    * @pdOid 4f1d8041-88e3-4484-9c02-b42393bc5814 */
   public static void main(String[] agrs) {
      Singleton app=Singleton.getInstance();
      
      // TODO: implement
   }

}