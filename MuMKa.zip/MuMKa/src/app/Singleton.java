/***********************************************************************
 * Module:  Singleton.java
 * Author:  Petar
 * Purpose: Defines the Class Singleton
 ***********************************************************************/

package app;

import java.awt.Image;

import javax.swing.ImageIcon;

/** @pdOid 0a6ecc7f-ad38-4b81-97b1-76acb7f15afa */
public class Singleton {
   /** @pdOid b6a7dfb7-f3f3-4689-a809-3d9630e3af3e */
   private static Singleton instance;
   
   /** @pdRoleInfo migr=no name=MainFrame assc=association1 mult=1..1 type=Composition */
   public MainFrame mainFrame;
   /** @pdRoleInfo migr=no name=LoadingDialog assc=association2 mult=1..1 type=Composition */
   
   
   /** @pdOid 90822401-4993-4bc1-8796-a1823440f01c */
   public static Singleton getInstance() {
      // TODO: implement
      if(instance==null) {
    	  instance=new Singleton();
    	  instance.init();
      }
      return instance;
   }
   
   /** @pdOid 93112355-8d88-4699-a5af-95c4529ba6f8 */
   public void init() {
	   mainFrame=new MainFrame();
	   mainFrame.initGUI();
      // TODO: implement
   }
   public static ImageIcon ikona(String loc) {
		ImageIcon ikonica3=new ImageIcon(loc);
		Image img = ikonica3.getImage();
		Image newimg = img.getScaledInstance(12, 12,  java.awt.Image.SCALE_SMOOTH);
		return new ImageIcon(newimg);
	}
}