/***********************************************************************
 * Module:  MainFrame.java
 * Author:  Petar
 * Purpose: Defines the Class MainFrame
 ***********************************************************************/

package app;

import java.awt.BorderLayout;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;

import control.ZatvaranjeAlata;
import model.Workspace;
import view.LoadingDialog;
import view.LoadingPanel;
import view.MenuBar;
import view.TreeHandler;

/** @pdOid 07d75ff6-a14a-4c33-81e4-a2a9886906f1 */
@SuppressWarnings("serial")
public class MainFrame extends JFrame {
   /** @pdOid ca632129-7329-468f-b1f0-5301d403bf9d */
   private Workspace workspace;
   private Parameters param;
   /** @pdOid 230e2351-c78e-4073-af26-3bb3bf3951f3 */
   private TreeHandler treeHandler;
   private LoadingDialog loadingDialog;
   private JScrollPane scrollPaneView;
   private JSplitPane splitPane;
   private MenuBar menu;
   private ResourceBundle resourceBundle;
   public MainFrame() {
	   Locale.setDefault(new Locale("sr","RS"));
		resourceBundle =ResourceBundle.getBundle( "gui.MessageResources.MessageResources", Locale.getDefault());
	   
	   
   }
   /** @pdOid 11932c3b-1d68-472a-9dd7-2b97564ce7d4 */
   public void initGUI() {
	   loadingDialog=new LoadingDialog(this,"Ucitavanje");
	   loadingDialog.setVisible(true);
	   if (loadingDialog.getClosingMode() == LoadingDialog.OK) {
			
			LoadingPanel pan = (LoadingPanel)loadingDialog.getPanel();
			if(pan.getPathTextField().getText()!="") {
				File fileRoot = new File(pan.getPathTextField().getText());
				this.treeHandler = new TreeHandler();
				this.workspace = new Workspace(fileRoot.getName(),fileRoot);
				this.treeHandler.setWorkspace(this.workspace);
				this.treeHandler.initTree();
				initParams();
				setTitle("Mumka");
				setSize(1200,800);
				setLocationRelativeTo(null);
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				menu = new MenuBar(this);
				this.setJMenuBar(menu);
				splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
				JScrollPane scrollPaneTree = new JScrollPane(this.treeHandler.getTree());
				scrollPaneView = new JScrollPane(new JPanel());
				splitPane.add(scrollPaneTree);
				splitPane.add(scrollPaneView);
				
				this.add(splitPane, BorderLayout.CENTER);
				this.setVisible(true);
				this.addWindowListener(new ZatvaranjeAlata());
			}
	   }else {
		   this.dispose();
	   }
      // TODO: implement
   }
  
   /** @pdOid 44bfdb75-faa1-4a47-b54c-11002c87c8c1 */
   public Workspace getWorkspace() {
      return workspace;
   }
   
   /** @param newWorkspace
    * @pdOid 02e22013-cf00-41f2-bcbd-9639e99086eb */
   public void setWorkspace(Workspace newWorkspace) {
      workspace = newWorkspace;
   }
   
   /** @pdOid 26d08b40-4b1c-44b9-bbd0-0943bddf402b */
   public TreeHandler getTreeHandler() {
      return treeHandler;
   }
   
   /** @param newTreeHandler
    * @pdOid 9ca1df1a-509a-4657-b198-475e04a8d427 */
   public void setTreeHandler(TreeHandler newTreeHandler) {
      treeHandler = newTreeHandler;
   }
   public JSplitPane getSplitPane() {
	return splitPane;
}
public void setSplitPane(JSplitPane splitPane) {
	this.splitPane = splitPane;
}
public JScrollPane getScrollPaneView() {
	return scrollPaneView;
}
public void setScrollPaneView(JScrollPane scrollPaneView) {
	this.scrollPaneView = scrollPaneView;
}
public void initParams() {
	File f = new File("parameters.p");
	ObjectInputStream oos=null;
	Parameters p=new Parameters();
	if(f.exists()) {
		try {
			oos = new ObjectInputStream(new BufferedInputStream(new FileInputStream(f)));
			p=(Parameters)oos.readObject();
			oos.close();
			
		} catch ( IOException | ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}else {
		p=new Parameters(false,false,false,false);
	}
	this.param=p;
}
public Parameters getParam() {
	return param;
}
public void setParam(Parameters param) {
	this.param = param;
}

}