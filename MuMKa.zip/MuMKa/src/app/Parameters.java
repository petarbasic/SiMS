/***********************************************************************
 * Module:  Parameters.java
 * Author:  Petar
 * Purpose: Defines the Class Parameters
 ***********************************************************************/

package app;

import java.io.Serializable;

/** @pdOid 58702491-642e-4738-894d-30cc46182f56 */
public class Parameters implements Serializable {
   /** @pdOid c2ab184b-f479-4ae9-a92b-f78449f328f6 */
   private boolean text;
   /** @pdOid e0bbfa67-543e-40af-864f-17e44f0cc1ab */
   private boolean video;
   /** @pdOid b2b239cb-f704-4a2f-bc12-ce6e1808f0c1 */
   private boolean picture;
   /** @pdOid 62acfd4d-e86a-48d9-b876-39a996820145 */
   private boolean audio;
   
   /** @param t 
    * @param v 
    * @param p 
    * @param a
    * @pdOid 8e55235b-a24b-488b-a613-41179b910d0e */
   public Parameters(boolean t, boolean v, boolean p, boolean a) {
	   this.text=t;
	   this.video=v;
	   this.picture=p;
	   this.audio=a;
      // TODO: implement
   }
   
   /** @pdOid 2d130774-3384-44c5-97fd-f51be14ecd9a */
   public Parameters() {
	   this.text=false;
	   this.video=false;
	   this.picture=false;
	   this.audio=false;
      // TODO: implement
   }

public boolean isText() {
	return text;
}

public void setText(boolean text) {
	this.text = text;
}

public boolean isVideo() {
	return video;
}

public void setVideo(boolean video) {
	this.video = video;
}

public boolean isPicture() {
	return picture;
}

public void setPicture(boolean picture) {
	this.picture = picture;
}

public boolean isAudio() {
	return audio;
}

public void setAudio(boolean audio) {
	this.audio = audio;
}

}